import React from "react";

const Title = ({ meal }) => {
  return (
    <div>
      <h1>title:{meal.strMeal}</h1>
    </div>
  );
};
export default Title;
